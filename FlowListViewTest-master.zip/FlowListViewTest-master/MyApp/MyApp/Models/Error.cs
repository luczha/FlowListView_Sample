﻿using System;
namespace MyApp.Models
{
    public class Error
    {
        public int Code { get; set; }
        public string error { get; set; }
        public string error_description { get; set; }
        public string error_types { get; set; }
    }
}

﻿namespace MyApp.Models
{
    public class Geo
    {
        public string lat { get; set; }
        public string lng { get; set; }
    }
}
﻿using System;
namespace MyApp.Models
{
    public class UserAlbums
    {
        public int userId { get; set; }
        public int id { get; set; }
        public string title { get; set; }
    }
}

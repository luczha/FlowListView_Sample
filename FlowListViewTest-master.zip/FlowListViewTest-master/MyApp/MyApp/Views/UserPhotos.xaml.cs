﻿using System;
using System.Collections.Generic;
using MyApp.Models;
using MyApp.ViewModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Collections.ObjectModel;
namespace MyApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UserPhotos : ContentPage
    {
        UserPhotosViewModel vm;

        public ObservableCollection<string> MyItems { get; set; }

        public UserPhotos(Users users)
        {
            InitializeComponent();
            BindingContext = this;

           listview.FlowItemsSource= MyItems = new ObservableCollection<string>() {"1111","222222","33333","444444" };

        }

    }
}
